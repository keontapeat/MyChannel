import Foundation

extension Notification.Name {
    static let stopAllPlayback = Notification.Name("StopAllPlaybackNow")
}


